import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './components/Login/Login'; 
import VistaEstudiante from "./components/Estudiante/Estudiante";
import VistaDocente from "./components/Docente/Docente";
import VistaCoordinador from "./components/Coordinador/Coordinador";
import VistaDirector from "./components/Director/Director";
//import { isAuthenticated } from './components/services/authService';

function ProtectedRoute({ element }) {
    //return isAuthenticated() ? element : <Navigate to="/login" replace />;
    return element;
  }

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Login />} />
        <Route path="/estudiante" element={<ProtectedRoute element={<VistaEstudiante />} />} />
        <Route path="/docente" element={<ProtectedRoute element={<VistaDocente />} />} />
        <Route path="/coordinador" element={<ProtectedRoute element={<VistaCoordinador />} />} />
        <Route path="/director" element={<ProtectedRoute element={<VistaDirector />} />} />
      </Routes>
    </Router>
  );
}

export default App;
//<a href="https://www.freepik.es/search">Icono de Freepik</a> referencia para todos los iconos que usamos de Freepik