import React, { useState } from "react";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import styles from "./Login.module.css";
import googlelogo from "../../assets/googlelogo.png";
import ojoContra from "../../assets/ojoContra.gif";
import api from "../../services/api"; // Importar configuración de Axios

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [emailError, setEmailError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [showPassword, setShowPassword] = useState(false);

    const navigate = useNavigate(); // Hook para navegar entre rutas

    const validarEmail = (email) => {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@ucb\.edu\.bo$/;
        return emailRegex.test(email);
    };

    const validarPassword = (password) => {
        const passwordRegex = /^(?=.*[A-Z])(?=.*\d).{7,}$/;
        return passwordRegex.test(password);
    };

    const togglePasswordVisibility = () => {
        setShowPassword((prevShowPassword) => !prevShowPassword);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
    
        let isValid = true;
    
        if (!validarEmail(email)) {
            setEmailError("El correo debe terminar en @ucb.edu.bo.");
            isValid = false;
        } else {
            setEmailError("");
        }
    
        if (!validarPassword(password)) {
            setPasswordError("La contraseña debe tener más de 6 caracteres, una mayúscula y un número.");
            isValid = false;
        } else {
            setPasswordError("");
        }
    
        if (isValid) {
            // Datos estáticos para la simulación
            const staticUsers = [
                { email: "estudiante@ucb.edu.bo", password: "Est1234", role: "estudiante" },
                { email: "docente@ucb.edu.bo", password: "Doc1234", role: "docente" },
                { email: "coordinador@ucb.edu.bo", password: "Coo1234", role: "coordinador" },
                { email: "director@ucb.edu.bo", password: "Dir1234", role: "director" },
            ];
    
            // Verificar usuario estático
            const user = staticUsers.find((user) => user.email === email && user.password === password);
            if (user) {
                Swal.fire({
                    title: "Inicio de sesión exitoso",
                    text: `Bienvenido a la plataforma como ${user.role}.`,
                    icon: "success",
                    confirmButtonText: "OK",
                }).then(() => {
                    // Redirigir según el rol del usuario
                    switch (user.role) {
                        case "estudiante":
                            navigate("/estudiante");
                            break;
                        case "docente":
                            navigate("/docente");
                            break;
                        case "coordinador":
                            navigate("/coordinador");
                            break;
                        case "director":
                            navigate("/director");
                            break;
                        default:
                            navigate("/login");
                    }
                });
            } else {
                // Si no coincide con los datos estáticos, muestra un error
                Swal.fire({
                    title: "Error",
                    text: "Correo o contraseña incorrectos.",
                    icon: "error",
                    confirmButtonText: "OK",
                });
            }
    
            // **Desactivamos la lógica del backend para esta simulación**
            return;
        } else {
            Swal.fire({
                title: "Error",
                text: "Corrige los errores antes de enviar.",
                icon: "error",
                confirmButtonText: "OK",
            });
        }
    };
    

    const handleGoogleLogin = () => {
        window.google.accounts.id.initialize({
            client_id: "TU_CLIENT_ID_DE_GOOGLE",
            callback: handleCredentialResponse,
        });

        window.google.accounts.id.prompt();
    };

    const handleCredentialResponse = (response) => {
        console.log("Google ID Token:", response.credential);

        Swal.fire({
            title: "Inicio de sesión con Google exitoso",
            text: "¡Bienvenido a la plataforma!",
            icon: "success",
            confirmButtonText: "OK",
        }).then(() => {
            navigate("/estudiante"); // Cambiar redirección según el rol si es necesario
        });
    };

    return (
        <div className={styles["login-background"]}>
            <div className={styles["login-container"]}>
                <h1>Inicio de Sesión</h1>
                <form onSubmit={handleSubmit} id="login-form">
                    <input
                        type="email"
                        placeholder="Correo electrónico"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className={styles.barra}
                    />
                    {emailError && <div className={styles["error-message"]}>{emailError}</div>}

                    <div className={styles["password-container"]}>
                        <input
                            type={showPassword ? "text" : "password"}
                            placeholder="Contraseña"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            className={styles.barra}
                        />
                        <button
                            type="button"
                            onClick={togglePasswordVisibility}
                            className={styles["toggle-password"]}
                        >
                            <img src={ojoContra} alt="Mostrar contraseña" />
                        </button>
                    </div>
                    {passwordError && <div className={styles["error-message"]}>{passwordError}</div>}

                    <button type="submit" className={styles["btn-submit"]}>Iniciar Sesión</button>
                </form>
                <button className={styles["google-login"]} onClick={handleGoogleLogin}>
                    <img src={googlelogo} alt="Google Logo" className={styles["google-icon"]} />
                    Iniciar Sesión con Google
                </button>
            </div>
        </div>
    );
};

export default Login;
