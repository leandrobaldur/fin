import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Modal from "react-modal";
import styles from "./Coordinador.module.css";
import usuarioIcon from "../../assets/usuarioIcon.gif";
import iconoDescarga from "../../assets/iconoDescarga.gif";
import iconoObservacion from "../../assets/iconoObservacion.gif";
import api from "../../services/api"; // Importar configuración de Axios

const Coordinador = () => {
    const navigate = useNavigate();

    const [activeTab, setActiveTab] = useState("propuestas");
    const [propuestas, setPropuestas] = useState([]);
    const [selectedPropuesta, setSelectedPropuesta] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [observacion, setObservacion] = useState("");
    const [showUserMenu, setShowUserMenu] = useState(false);
    const [estados, setEstados] = useState([]);

    const handleLogout = () => {
        navigate("/login");
    };

    // Obtener propuestas desde el backend
    useEffect(() => {
        const fetchPropuestas = async () => {
            try {
                const response = await api.get("/proposals/");
                setPropuestas(response.data);
            } catch (error) {
                console.error("Error al cargar las propuestas:", error);
            }
        };

        const fetchEstados = async () => {
            try {
                const response = await api.get("/proposal_states/");
                setEstados(response.data); // Almacenar los estados
            } catch (error) {
                console.error("Error al cargar los estados:", error);
            }
        };

        fetchPropuestas();
        fetchEstados();
    }, []);

    // Función para actualizar el estado de una propuesta
    const updateProposalState = async (proposalId, newStateId) => {
        try {
            const response = await api.put(`/proposals/${proposalId}`, { state_id: newStateId });
            setPropuestas((prev) =>
                prev.map((proposal) =>
                    proposal.id === proposalId ? { ...proposal, state_id: newStateId } : proposal
                )
            );
            alert("Estado actualizado exitosamente");
        } catch (error) {
            console.error("Error al actualizar el estado de la propuesta:", error);
            alert("Error al actualizar el estado");
        }
    };

    const handleObservaciones = (propuesta) => {
        setSelectedPropuesta(propuesta);
        setObservacion(propuesta.observacion || ""); // Si ya tiene observaciones, las mostramos
        setIsModalOpen(true);
    };

    const saveObservaciones = async () => {
        if (selectedPropuesta) {
            try {
                const updatedPropuesta = {
                    ...selectedPropuesta,
                    description: observacion,
                };

                const response = await api.put(`/proposals/${selectedPropuesta.id}`, updatedPropuesta);

                setPropuestas((prev) =>
                    prev.map((p) => (p.id === selectedPropuesta.id ? response.data : p))
                );

                alert("Observaciones guardadas exitosamente");
                setIsModalOpen(false);
                setSelectedPropuesta(null);
                setObservacion("");
            } catch (error) {
                console.error("Error al guardar las observaciones:", error);
                alert("Error al guardar las observaciones");
            }
        }
    };

    const handleDescargarPropuesta = (filePath) => {
        if (filePath) {
            window.open(filePath, "_blank");
        } else {
            alert("Archivo no disponible para descargar");
        }
    };

    const renderPropuestas = () => (
        <div className={styles.tabContent}>
            {propuestas.map((propuesta) => (
                <div key={propuesta.id} className={styles.propuestaItem}>
                <h3>{propuesta.title}</h3>
                <p><strong>Estudiante:</strong> {propuesta.student_id}</p>
                <p><strong>Estado:</strong> {propuesta.state_id}</p>

                <button
                    onClick={() => handleObservaciones(propuesta)}
                    className={styles.btnObservacion}
                >
                    <img src={iconoObservacion} alt="Escribir Observaciones" /> Escribir Observaciones
                </button>
                <button className={styles.btnDescargar}>
                    <img src={iconoDescarga} alt="Descargar Propuesta" /> Descargar Propuesta
                </button>
                <select
                    className={styles.stateDropdown} 
                    value={propuesta.state_id}
                    onChange={(e) => updateProposalState(propuesta.id, parseInt(e.target.value))}
                >
                    <option value="1">Aprobado</option>
                    <option value="2">Con Observaciones</option>
                    <option value="3">No Aprobado</option>
                </select>
            </div>
            ))}
        </div>
    );

    return (
        <div className={styles.coordinadorContainer}>
            <header className={styles.navbar}>
                <h1>Portal Coordinador</h1>
                <nav className={styles.tabNav}>
                    <button
                        onClick={() => setActiveTab("propuestas")}
                        className={`${styles.tab} ${activeTab === "propuestas" ? styles.active : ""}`}
                    >
                        Propuestas y Cartas de Estudiantes
                    </button>
                </nav>

                <div
                    className={styles["usuario-wrapper"]}
                    onMouseEnter={() => setShowUserMenu(true)}
                    onMouseLeave={() => setShowUserMenu(false)}
                >
                    <button className={styles["usuario-btn"]}>
                        <img src={usuarioIcon} alt="Usuario Logo" className={styles["usuario-logo"]} />
                        Usuario
                    </button>
                    {showUserMenu && (
                        <nav
                            className={styles["opciones-usuario"]}
                            onMouseEnter={() => setShowUserMenu(true)}
                            onMouseLeave={() => setShowUserMenu(false)}
                        >
                            <ul>
                                <li>
                                    <button className={styles.linkButton}>Personalizar</button>
                                </li>
                                <li>
                                    <button className={styles.linkButton}>Configuración</button>
                                </li>
                                <li>
                                    <button className={styles.linkButton} onClick={handleLogout}>
                                        Cerrar Sesión
                                    </button>
                                </li>
                            </ul>
                        </nav>
                    )}
                </div>
            </header>

            <div className={styles.tabContentContainer}>
                {activeTab === "propuestas" && renderPropuestas()}
            </div>

            <Modal
                isOpen={isModalOpen}
                onRequestClose={() => setIsModalOpen(false)}
                contentLabel="Escribir Observaciones"
                className={styles["modal-observaciones"]}
                overlayClassName={styles.overlay}
            >
                <h2>Escribir Observaciones</h2>

                <textarea
                    placeholder="Escribe tus observaciones aquí..."
                    className={styles["textarea-observaciones"]}
                    value={observacion}
                    onChange={(e) => setObservacion(e.target.value)}
                />

                <div className={styles["button-group-observaciones"]}>
                    <button
                        onClick={saveObservaciones}
                        className={styles["save-button"]}
                    >
                        Guardar Cambios
                    </button>

                    <button
                        onClick={() => setIsModalOpen(false)}
                        className={styles["cancel-button"]}
                    >
                        Cancelar
                    </button>
                </div>
            </Modal>
            <footer className={styles.footer}>
                &copy; 2024 Proyecto Tec Web - Todos los derechos reservados - COORDINADOR
            </footer>
        </div>
    );
};

export default Coordinador;
