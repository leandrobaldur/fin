import jwtDecode from 'jwt-decode';

const ACCESS_TOKEN_KEY = "accessToken";
const REFRESH_TOKEN_KEY = "refreshToken";

export function getToken() {
    return localStorage.getItem(ACCESS_TOKEN_KEY);
}

export function setToken(token) {
    localStorage.setItem(ACCESS_TOKEN_KEY, token);
}

export function removeToken() {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
}

export function getRefreshToken() {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
}

export function setRefreshToken(token) {
    localStorage.setItem(REFRESH_TOKEN_KEY, token);
}

export function removeRefreshToken() {
    localStorage.removeItem(REFRESH_TOKEN_KEY);
}

export function isTokenExpired(token) {
    if (!token) return true;
    const decodedToken = jwtDecode(token);
    const currentTime = Date.now() / 1000; // time in seconds
    return decodedToken.exp < currentTime; 
}

export function isAuthenticated() {
    const token = getToken();
    return token && !isTokenExpired(token);
}

export async function refreshToken() {
    const refreshToken = getRefreshToken();
    if (!refreshToken) throw new Error("No refresh token available");

    try {
        const response = await fetch('/api/auth/refresh-token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ refreshToken }),
        });

        if (!response.ok) {
            removeToken();
            removeRefreshToken();
            throw new Error("Failed to refresh token");
        }

        const data = await response.json();
        const { accessToken, refreshToken: newRefreshToken } = data;

        if (accessToken) setToken(accessToken);
        if (newRefreshToken) setRefreshToken(newRefreshToken);

        return accessToken;
    } catch (error) {
        console.error("Token refresh error:", error);
        throw error;
    }
}

// Log out helper function
export function logout() {
    removeToken();
    removeRefreshToken();
    window.location.href = "/login"; // Redirect to login page
}
