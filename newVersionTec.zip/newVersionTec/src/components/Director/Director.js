import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Modal from "react-modal";
import Swal from "sweetalert2";
import styles from "./Director.module.css";
import usuarioIcon from "../../assets/usuarioIcon.gif";
import iconoDescarga from "../../assets/iconoDescarga.gif";
import iconoObservacion from "../../assets/iconoObservacion.gif";
import api from "../../services/api";

const Director = () => {
    const navigate = useNavigate();
    const handleLogout = () => {
        navigate("/login");
    };

    const [activeTab, setActiveTab] = useState("propuestas");
    const [propuestas, setPropuestas] = useState([]);
    const [tesis, setTesis] = useState([]);
    const [filteredTesis, setFilteredTesis] = useState([]);
    const [selectedPropuesta, setSelectedPropuesta] = useState(null);
    const [tesisSeleccionada, setTesisSeleccionada] = useState(null);
    const [filtroTitulo, setFiltroTitulo] = useState("");
    const [filtroAutor, setFiltroAutor] = useState("");
    const [filtroTutor, setFiltroTutor] = useState("");
    const [filtroAño, setFiltroAño] = useState("");
    const [filtroCategoria, setFiltroCategoria] = useState("");
    const [observacion, setObservacion] = useState("");
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [showUserMenu, setShowUserMenu] = useState(false);

    useEffect(() => {
        const fetchPropuestas = async () => {
            try {
                const response = await api.get("/proposals/");
                setPropuestas(response.data);
            } catch (error) {
                console.error("Error al obtener propuestas:", error);
            }
        };
        fetchPropuestas();
    }, []);

    useEffect(() => {
        const fetchTesis = async () => {
            try {
                const response = await api.get("/theses/");
                setTesis(response.data);
                setFilteredTesis(response.data);
            } catch (error) {
                console.error("Error al obtener tesis:", error);
            }
        };
        fetchTesis();
    }, []);

    useEffect(() => {
        let resultados = tesis;

        if (filtroTitulo) resultados = resultados.filter(t => t.title.toLowerCase().includes(filtroTitulo.toLowerCase()));
        if (filtroAutor) resultados = resultados.filter(t => t.author.toLowerCase().includes(filtroAutor.toLowerCase()));
        if (filtroTutor) resultados = resultados.filter(t => t.tutor.toLowerCase().includes(filtroTutor.toLowerCase()));
        if (filtroAño) resultados = resultados.filter(t => t.year.includes(filtroAño));
        if (filtroCategoria) resultados = resultados.filter(t => t.category.toLowerCase().includes(filtroCategoria.toLowerCase()));

        setFilteredTesis(resultados);
    }, [filtroTitulo, filtroAutor, filtroTutor, filtroAño, filtroCategoria, tesis]);

    const saveObservaciones = async () => {
        if (!selectedPropuesta) return;

        try {
            const updatedPropuesta = { ...selectedPropuesta, description: observacion };
            await api.put(`/proposals/${selectedPropuesta.id}`, updatedPropuesta);

            setPropuestas(prev =>
                prev.map(p => (p.id === selectedPropuesta.id ? updatedPropuesta : p))
            );
            setIsModalOpen(false);
            setObservacion("");
            Swal.fire("Guardado", "Observaciones actualizadas exitosamente.", "success");
        } catch (error) {
            console.error("Error al guardar observaciones:", error);
            Swal.fire("Error", "No se pudo actualizar la propuesta.", "error");
        }
    };

    const handleSaveChanges = async () => {
        if (!tesisSeleccionada) return;

        try {
            await api.put(`/theses/${tesisSeleccionada.id}`, tesisSeleccionada);

            setTesis(prev =>
                prev.map(t => (t.id === tesisSeleccionada.id ? tesisSeleccionada : t))
            );
            setIsEditModalOpen(false);
            Swal.fire("Guardado", "La tesis ha sido actualizada exitosamente.", "success");
        } catch (error) {
            console.error("Error al guardar tesis:", error);
            Swal.fire("Error", "No se pudo actualizar la tesis.", "error");
        }
    };

    const renderPropuestas = () => (
        <div className={styles.tabContent}>
            {propuestas.map(propuesta => (
                <div key={propuesta.id} className={styles.propuestaItem}>
                    <h3>{propuesta.title}</h3>
                    <p><strong>Estudiante:</strong> {propuesta.student_id}</p>
                    <p><strong>Estado:</strong> {propuesta.state_id}</p>
                    <button
                        onClick={() => {
                            setSelectedPropuesta(propuesta);
                            setObservacion(propuesta.description || "");
                            setIsModalOpen(true);
                        }}
                        className={styles.btnObservacion}
                    >
                        <img src={iconoObservacion} alt="Escribir Observaciones" /> Escribir Observaciones
                    </button>
                </div>
            ))}
        </div>
    );

    const renderRegistroTesis = () => (
        <div>
            <div className={styles.filtros}>
                <input type="text" placeholder="Filtrar por título" value={filtroTitulo} onChange={(e) => setFiltroTitulo(e.target.value)} />
                <input type="text" placeholder="Filtrar por autor" value={filtroAutor} onChange={(e) => setFiltroAutor(e.target.value)} />
                <input type="text" placeholder="Filtrar por tutor" value={filtroTutor} onChange={(e) => setFiltroTutor(e.target.value)} />
                <input type="text" placeholder="Filtrar por año" value={filtroAño} onChange={(e) => setFiltroAño(e.target.value)} />
                <input type="text" placeholder="Filtrar por categoría" value={filtroCategoria} onChange={(e) => setFiltroCategoria(e.target.value)} />
            </div>
            <div className={styles.tesisExistentes}>
                {filteredTesis.map(t => (
                    <div key={t.id} className={styles.tesisItem}>
                        <h3>{t.title}</h3>
                        <p><strong>Autor:</strong> {t.author}</p>
                        <p><strong>Tutor:</strong> {t.tutor}</p>
                        <p><strong>Año:</strong> {t.year}</p>
                        <p><strong>Categoría:</strong> {t.category}</p>
                        <button
                            onClick={() => {
                                setTesisSeleccionada(t);
                                setIsEditModalOpen(true);
                            }}
                            className={styles.editButton}
                        >
                            Editar
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );

    return (
        <div className={styles.directorContainer}>
            <header className={styles.navbar}>
                <h1>Portal Director</h1>
                <nav className={styles.tabNav}>
                    <button onClick={() => setActiveTab("propuestas")} className={`${styles.tab} ${activeTab === "propuestas" ? styles.active : ""}`}>
                        Propuestas y Cartas de Estudiantes
                    </button>
                    <button onClick={() => setActiveTab("registroTesis")} className={`${styles.tab} ${activeTab === "registroTesis" ? styles.active : ""}`}>
                        Registro de Tesis
                    </button>
                </nav>
                <div
                    className={styles["usuario-wrapper"]}
                    onMouseEnter={() => setShowUserMenu(true)}
                    onMouseLeave={() => setShowUserMenu(false)}
                >
                    <button className={styles["usuario-btn"]}>
                        <img src={usuarioIcon} alt="Usuario Logo" className={styles["usuario-logo"]} />
                        Usuario
                    </button>
                    {showUserMenu && (
                        <nav
                            className={styles["opciones-usuario"]}
                            onMouseEnter={() => setShowUserMenu(true)}
                            onMouseLeave={() => setShowUserMenu(false)}
                        >
                            <ul>
                                <li>
                                    <button className={styles.linkButton}>Personalizar</button>
                                </li>
                                <li>
                                    <button className={styles.linkButton}>Configuración</button>
                                </li>
                                <li>
                                    <button className={styles.linkButton} onClick={handleLogout}>
                                        Cerrar Sesión
                                    </button>
                                </li>
                            </ul>
                        </nav>
                    )}
                </div>
            </header>
            <div className={styles.tabContentContainer}>
                {activeTab === "propuestas" && renderPropuestas()}
                {activeTab === "registroTesis" && renderRegistroTesis()}
            </div>
            <Modal
                isOpen={isModalOpen}
                onRequestClose={() => setIsModalOpen(false)}
                contentLabel="Escribir Observaciones"
                className={styles["modal-observaciones"]}
                overlayClassName={styles.overlay}
            >
                <h2>Escribir Observaciones</h2>
                <textarea
                    placeholder="Escribe tus observaciones aquí..."
                    className={styles["textarea-observaciones"]}
                    value={observacion}
                    onChange={(e) => setObservacion(e.target.value)}
                />
                <div className={styles["button-group-observaciones"]}>
                    <button onClick={saveObservaciones} className={styles["save-button"]}>
                        Guardar Cambios
                    </button>
                    <button onClick={() => setIsModalOpen(false)} className={styles["cancel-button"]}>
                        Cancelar
                    </button>
                </div>
            </Modal>
            <Modal
                isOpen={isEditModalOpen}
                onRequestClose={() => setIsEditModalOpen(false)}
                contentLabel="Editar Tesis"
                className={styles.modal}
                overlayClassName={styles.overlay}
            >
                {tesisSeleccionada && (
                    <div>
                        <h2>Editar Tesis</h2>
                        <div className={styles["form-group"]}>
                            <input
                                type="text"
                                value={tesisSeleccionada.title}
                                onChange={(e) => setTesisSeleccionada({ ...tesisSeleccionada, title: e.target.value })}
                                placeholder="Título"
                            />
                            <input
                                type="text"
                                value={tesisSeleccionada.author}
                                onChange={(e) => setTesisSeleccionada({ ...tesisSeleccionada, author: e.target.value })}
                                placeholder="Autor"
                            />
                            <input
                                type="text"
                                value={tesisSeleccionada.tutor}
                                onChange={(e) => setTesisSeleccionada({ ...tesisSeleccionada, tutor: e.target.value })}
                                placeholder="Tutor"
                            />
                            <input
                                type="text"
                                value={tesisSeleccionada.year}
                                onChange={(e) => setTesisSeleccionada({ ...tesisSeleccionada, year: e.target.value })}
                                placeholder="Año"
                            />
                            <input
                                type="text"
                                value={tesisSeleccionada.category}
                                onChange={(e) => setTesisSeleccionada({ ...tesisSeleccionada, category: e.target.value })}
                                placeholder="Categoría"
                            />
                        </div>
                        <div className={styles["button-group"]}>
                            <button onClick={handleSaveChanges} className={styles["save-button"]}>Guardar Cambios</button>
                            <button onClick={() => setIsEditModalOpen(false)} className={styles["cancel-button"]}>Cancelar</button>
                        </div>
                    </div>
                )}
            </Modal>
            <footer className={styles.footer}>
                &copy; 2024 Proyecto Tec Web - Todos los derechos reservados - DIRECTOR
            </footer>
        </div>
    );
};

export default Director;
