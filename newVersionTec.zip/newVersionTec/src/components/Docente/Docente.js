import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Modal from "react-modal";
import api from "../../services/api"; 
import styles from "./Docente.module.css";
import usuarioIcon from "../../assets/usuarioIcon.gif";
import iconoDescarga from "../../assets/iconoDescarga.gif";
import iconoObservacion from "../../assets/iconoObservacion.gif";

const Coordinador = () => {
    const navigate = useNavigate(); 
    const [activeTab, setActiveTab] = useState("propuestas");
    const [propuestas, setPropuestas] = useState([
        { id: 1, titulo: "Desarrollo Web", estudiante: "Juan Pérez", carrera: "Ingeniería", tutor: "Dr. López", fechaActualizacion: "2023-05-15", estado: "Aprobado" },
        { id: 2, titulo: "Nueva Ley 408", estudiante: "Eduardo Savedra", carrera: "Derecho", tutor: "Dr. Miranda", fechaActualizacion: "20234-01-19", estado: "Observado" }
    ]);
    const [selectedPropuesta, setSelectedPropuesta] = useState(null); 
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [showUserMenu, setShowUserMenu] = useState(false);
    const [observacion, setObservacion] = useState("");

    const handleLogout = () => {
            navigate("/login");
        };
    
    useEffect(() => {
        const fetchPropuestas = async () => {
            try {
                const response = await api.get("/proposals/");
                setPropuestas(response.data);
            } catch (error) {
                console.error("Error al cargar las propuestas:", error);
            }
        };
        fetchPropuestas();
    }, []);

    const handleObservaciones = (propuesta) => {
        setSelectedPropuesta(propuesta);
        setIsModalOpen(true);
    };

    const renderPropuestas = () => (
        <div className={styles.tabContent}>
            {propuestas.map((propuesta) => (
                <div key={propuesta.id} className={styles.propuestaItem}>
                    <h3>{propuesta.title}</h3>
                    <p><strong>Estudiante:</strong> {propuesta.student_id}</p>
                    <p><strong>Fecha de Actualización:</strong> {propuesta.created_at}</p>
                    <button
                        onClick={() => {
                            setSelectedPropuesta(propuesta);
                            setIsModalOpen(true);
                        }}
                        className={styles.btnObservacion}
                    >
                        <img src={iconoObservacion} alt="Escribir Observaciones" /> Escribir Observaciones
                    </button>
                    <button
                        className={styles.btnDescargar}
                        onClick={() => handleDescargarPropuesta(propuesta.file_path)}
                    >
                        <img src={iconoDescarga} alt="Descargar Propuesta" /> Descargar Propuesta
                    </button>
                </div>
            ))}
        </div>
    );

    const handleGuardarObservaciones = async () => {
        if (!observacion.trim()) {
            alert("Escribe una observación antes de guardar.");
            return;
        }

        try {
            const updatedPropuesta = {
                ...selectedPropuesta,
                description: observacion,
            };
            const response = await api.put(`/proposals/${selectedPropuesta.id}`, updatedPropuesta);
            setPropuestas(
                propuestas.map((propuesta) =>
                    propuesta.id === selectedPropuesta.id ? response.data : propuesta
                )
            );
            setIsModalOpen(false);
            setObservacion("");
        } catch (error) {
            console.error("Error al guardar observaciones:", error);
        }
    };

    const handleDescargarPropuesta = (filePath) => {
        window.open(filePath, "_blank");
    };

    return (
        <div className={styles.docenteContainer}>
            <header className={styles.navbar}>
                <h1>Portal Docente</h1>
                <nav className={styles.tabNav}>
                    <button onClick={() => setActiveTab("propuestas")} className={`${styles.tab} ${activeTab === "propuestas" ? styles.active : ""}`}>
                        Propuestas y Cartas de Estudiantes
                    </button>
                </nav>

                <div 
                    className={styles["usuario-wrapper"]}
                    onMouseEnter={() => setShowUserMenu(true)}
                    onMouseLeave={() => setShowUserMenu(false)}
                >
                    <button className={styles["usuario-btn"]}>
                        <img src={usuarioIcon} alt="Usuario Logo" className={styles["usuario-logo"]} />
                        Usuario
                    </button>
                    {showUserMenu && (
                        <nav 
                            className={styles["opciones-usuario"]} 
                            onMouseEnter={() => setShowUserMenu(true)} 
                            onMouseLeave={() => setShowUserMenu(false)}
                        >
                            <ul>
                                <li>
                                    <button className={styles.linkButton}>Personalizar</button>
                                </li>
                                <li>
                                <button className={styles.linkButton}>Configuración</button>
                                </li>
                                <li>
                                    <button className={styles.linkButton} onClick={handleLogout}>
                                        Cerrar Sesión
                                    </button>
                                </li>
                            </ul>
                        </nav>
                    )}
                </div>
            </header>

            <div className={styles.tabContentContainer}>
                {activeTab === "propuestas" && renderPropuestas()}
            </div>

            <Modal
                isOpen={isModalOpen}
                onRequestClose={() => setIsModalOpen(false)}
                contentLabel="Escribir Observaciones"
                className={styles["modal-observaciones"]}
                overlayClassName={styles.overlay}
            >
                <h2>Escribir Observaciones</h2>
                
                <textarea 
                    placeholder="Escribe tus observaciones aquí..." 
                    className={styles["textarea-observaciones"]}
                />
                
                <div className={styles["button-group-observaciones"]}>
                    <button 
                        onClick={() => {
                            setIsModalOpen(false);
                        }} 
                        className={styles["save-button"]}
                    >
                        Guardar Cambios
                    </button>
                    
                    <button 
                        onClick={() => setIsModalOpen(false)} 
                        className={styles["cancel-button"]}
                    >
                        Cancelar
                    </button>
                </div>
            </Modal>
            <footer className={styles.footer}>
                &copy; 2024 Proyecto Tec Web - Todos los derechos reservados - DOCENTE
            </footer>
        </div>
    );
};

export default Coordinador;
