import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Modal from "react-modal";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import styles from "./Estudiante.module.css";
import usuarioIcon from "../../assets/usuarioIcon.gif";
import notificacionesIcon from "../../assets/notificaciones.gif";
import iconoEliminarBasura from "../../assets/iconoEliminarBasura.gif";
import uploadIcon from "../../assets/uploadIcon.gif";
import formatoCartaPropuesta from "../../assets/formato_carta_propuesta.pdf";
import api from "../../services/api"; // Importar configuración de Axios

const noticias = [
    { id: 1, imagen: "https://via.placeholder.com/400x200", texto: "Primer aviso importante para los estudiantes." },
    { id: 2, imagen: "https://via.placeholder.com/400x200", texto: "Recuerda completar tus documentos antes de la fecha límite." },
    { id: 3, imagen: "https://via.placeholder.com/400x200", texto: "Nuevo taller de desarrollo web este fin de semana." },
];

const Estudiante = () => {
    const [activeTab, setActiveTab] = useState("inicio");
    const [currentNewsIndex, setCurrentNewsIndex] = useState(0);
    const [selectedFiles, setSelectedFiles] = useState([]);
    const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
    //const [propuestas, setPropuestas] = useState([]);
    const [materias, setMaterias] = useState([]);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [selectedPropuesta, setSelectedPropuesta] = useState(null);
    const [showUserMenu, setShowUserMenu] = useState(false);
    const [isAyudaModalOpen, setIsAyudaModalOpen] = useState(false);
    const [ayudaContenido, setAyudaContenido] = useState("");
    const [showAyudaMenu, setShowAyudaMenu] = useState(false);
    const [currentDate, setCurrentDate] = useState(new Date());
    const navigate = useNavigate();
    const [footerContent, setFooterContent] = useState("");
    const [usuario, setUsuario] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const fetchUsuario = async () => {
            try {
                const response = await api.get("/users/me");
                setUsuario(response.data);
            } catch (error) {
                console.error("Error al cargar datos del usuario:", error);
            }
        };
        fetchUsuario();
    }, []);

    const fetchPropuestas = async () => {
        setLoading(true);
        try {
            const response = await api.get("/proposals/");
            setPropuestas(response.data);
        } catch (error) {
            console.error("Error al cargar propuestas:", error);
        } finally {
            setLoading(false);
        }
    };
    

    //datos de prueba
    const [propuestas, setPropuestas] = useState([
        { id: 1, titulo: "Desarrollo Web", fechaSubida: "2023-05-15", estado: "Aprobado", observacion: "Propuesta sólida" },
        { id: 2, titulo: "Inteligencia Artificial", fechaSubida: "2023-06-20", estado: "En Revisión", observacion: "Ajustes en la sección 2" },
        { id: 3, titulo: "Desarrollo Web", fechaSubida: "2023-05-15", estado: "Aprobado", observacion: "Propuesta sólida" },
        { id: 4, titulo: "Desarrollo Web", fechaSubida: "2023-05-15", estado: "Aprobado", observacion: "Propuesta sólida" },
        
    ]);

    const handleLogout = () => {
        navigate("/login");
    };

    // Obtener propuestas desde el backend
    useEffect(() => {
        const fetchPropuestas = async () => {
            try {
                const response = await api.get("/proposals/");
                setPropuestas(response.data);
            } catch (error) {
                console.error("Error al cargar las propuestas:", error);
            }
        };
        fetchPropuestas();
    }, []);

    // Obtener materias desde el backend
    useEffect(() => {
        const fetchMaterias = async () => {
            try {
                const response = await api.get("/subjects/");
                setMaterias(response.data);
            } catch (error) {
                console.error("Error al cargar materias:", error);
            }
        };
        fetchMaterias();
    }, []);

    // Enviar nueva propuesta al backend
    const handleSubmitPropuesta = async () => {
        if (selectedFiles.length === 0) {
            alert("Por favor, seleccione uno o más archivos para subir.");
            return;
        }
    
        const formData = new FormData();
        formData.append("title", "Nueva Propuesta");
        formData.append("description", "Descripción de la propuesta.");
        selectedFiles.forEach((file) => {
            formData.append("files", file);
        });
    
        try {
            const response = await api.post("/proposals/", formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                },
            });
            setPropuestas([...propuestas, response.data]); 
            setSelectedFiles([]);
            setIsUploadModalOpen(false);
        } catch (error) {
            console.error("Error al subir la propuesta:", error);
        }
    };    

    const handleClearFiles = () => {
        setSelectedFiles([]);
    };
    
    const handleFileSelect = (event) => {
        setSelectedFiles(Array.from(event.target.files));
    };

    const handleRemoveFile = (index) => {
        const updatedFiles = [...selectedFiles];
        updatedFiles.splice(index, 1);
        setSelectedFiles(updatedFiles);
    };

    const handleEditModal = (propuesta) => {
        setSelectedPropuesta(propuesta);
        setIsEditModalOpen(true);
    };

    const handleNextNews = () => {
        setCurrentNewsIndex((currentNewsIndex + 1) % noticias.length);
    };

    const handlePrevNews = () => {
        setCurrentNewsIndex((currentNewsIndex - 1 + noticias.length) % noticias.length);
    };

    const handleOpenAyuda = (contenido) => {
        setAyudaContenido(contenido);
        setIsAyudaModalOpen(true);
    };
    
    const handleCloseAyuda = () => {
        setIsAyudaModalOpen(false);
        setAyudaContenido("");
    };

    const changeMonth = (direction) => {
        const newDate = new Date(currentDate);
        newDate.setMonth(newDate.getMonth() + direction);
        setCurrentDate(newDate);
    };
    
    const generateCalendarGrid = () => {
        const startDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const endDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
        const daysInMonth = endDate.getDate();
        const startDay = startDate.getDay();
    
        const daysArray = Array.from({ length: startDay + daysInMonth }, (_, index) => {
            const day = index - startDay + 1;
            return day > 0 ? day : null;
        });
    
        return daysArray;
    };
    
    const handleUpdatePropuesta = async (id, updatedData) => {
        try {
            const response = await api.put(`/proposals/${id}`, updatedData);
            setPropuestas(
                propuestas.map((propuesta) =>
                    propuesta.id === id ? response.data : propuesta
                )
            );
        } catch (error) {
            console.error("Error al actualizar la propuesta:", error);
        }
    };
    
    const handleDeletePropuesta = async (id) => {
        try {
            await api.delete(`/proposals/${id}`);
            setPropuestas(propuestas.filter((propuesta) => propuesta.id !== id));
        } catch (error) {
            console.error("Error al eliminar la propuesta:", error);
        }
    };
    
    const fetchPropuestasFiltradas = async (stateId) => {
        try {
            const response = await api.get(`/proposals/?state_id=${stateId}`);
            setPropuestas(response.data);
        } catch (error) {
            console.error("Error al filtrar propuestas:", error);
        }
    };
    
    const renderAyudaContenido = () => {
        switch (ayudaContenido) {
            case "subirCarta":
                return (
                    <>
                        <h3>Ayuda para Subir Carta y Propuesta</h3>
                        <div className={styles.carruselAyuda}>
                            <img src="https://via.placeholder.com/600x400" alt="Tutorial Subir Carta 1" />
                            <img src="https://via.placeholder.com/600x400" alt="Tutorial Subir Carta 2" />
                        </div>
                    </>
                );
            case "estadoPropuesta":
                return (
                    <>
                        <h3>Ayuda para Estado de la Propuesta</h3>
                        <div className={styles.carruselAyuda}>
                            <img src="https://via.placeholder.com/600x400" alt="Tutorial Estado Propuesta 1" />
                            <img src="https://via.placeholder.com/600x400" alt="Tutorial Estado Propuesta 2" />
                        </div>
                    </>
                );
            case "soporteErrores":
                return (
                    <>
                        <h3>Soporte de Errores</h3>
                        <div className={styles.carruselAyuda}>
                            <img src="https://via.placeholder.com/600x400" alt="Tutorial Soporte 1" />
                            <img src="https://via.placeholder.com/600x400" alt="Tutorial Soporte 2" />
                        </div>
                    </>
                );
            default:
                return <p>No se ha seleccionado ninguna opción de ayuda.</p>;
        }
    };

    return (
        <div className={styles["estudiante-container"]}>
            <header className={styles.navbar}>
                <h1 className={styles["navbar-title"]}>Portal del Estudiante</h1>
                <nav className={styles.tabNav}>
                    <button
                        className={`${styles.tab} ${activeTab === "inicio" ? styles.active : ""}`}
                        onClick={() => setActiveTab("inicio")}
                    >
                        Inicio
                    </button>
                    <button
                        className={`${styles.tab} ${activeTab === "preparar" ? styles.active : ""}`}
                        onClick={() => setActiveTab("preparar")}
                    >
                        Preparar carta y Propuesta
                    </button>
                    <button
                        className={`${styles.tab} ${activeTab === "estado" ? styles.active : ""}`}
                        onClick={() => setActiveTab("estado")}
                    >
                        Estado de la Propuesta
                    </button>
                    <div className={styles["dropdown-wrapper"]}>
                        <button
                            className={`${styles.tab}`}
                            onClick={() => setShowAyudaMenu(!showAyudaMenu)}
                            onBlur={() => setTimeout(() => setShowAyudaMenu(false), 200)}
                        >
                            Ayuda
                        </button>
                        {showAyudaMenu && (
                            <ul className={styles["dropdown-menu"]}>
                                <li
                                    onClick={() => {
                                        handleOpenAyuda("subirCarta");
                                        setShowAyudaMenu(false);
                                    }}
                                >
                                    Ayuda Subir Carta y Propuesta
                                </li>
                                <li
                                    onClick={() => {
                                        handleOpenAyuda("estadoPropuesta");
                                        setShowAyudaMenu(false);
                                    }}
                                >
                                    Ayuda Estado Propuesta
                                </li>
                                <li
                                    onClick={() => {
                                        handleOpenAyuda("soporteErrores");
                                        setShowAyudaMenu(false);
                                    }}
                                >
                                    Soporte de Errores
                                </li>
                            </ul>
                        )}
                    </div>
                </nav>
                <div
                    className={styles["usuario-wrapper"]}
                    onMouseEnter={() => setShowUserMenu(true)}
                    onMouseLeave={() => setShowUserMenu(false)}
                >
                    <button className={styles["usuario-btn"]}>
                        <img src={usuarioIcon} alt="Usuario Logo" className={styles["usuario-logo"]} />
                        Usuario
                    </button>
                    {showUserMenu && (
                        <nav className={styles["opciones-usuario"]}>
                            <ul>
                                <li>
                                    <button className={styles.linkButton}>Personalizar</button>
                                </li>
                                <li>
                                    <button className={styles.linkButton}>Configuración</button>
                                </li>
                                <li>
                                    <button className={styles.linkButton} onClick={handleLogout}>
                                        Cerrar Sesión
                                    </button>
                                </li>
                            </ul>
                        </nav>
                    )}
                </div>
            </header>

            <div className={styles.tabContentContainer}>
            {activeTab === "inicio" && (
                    <div className={styles.tabContentInicio}>
                        <div className={styles.newsCarousel}>
                            <button className={styles.prevButton} onClick={handlePrevNews}>{"<"}</button>
                            <div className={styles.newsContent}>
                                <img src={noticias[currentNewsIndex].imagen} alt="Noticia" className={styles.newsImage} />
                                {noticias[currentNewsIndex].texto && (
                                    <p className={styles.newsText}>{noticias[currentNewsIndex].texto}</p>
                                )}
                            </div>
                            <button className={styles.nextButton} onClick={handleNextNews}>{">"}</button>
                        </div>

                        <div className={styles.fullCalendar}>
                            <h3 className={styles.miniCalendarHeader}>
                                {currentDate.toLocaleString("default", { month: "long", year: "numeric" })}
                            </h3>
                            <div className={styles.miniCalendarGrid}>
                                {["D", "L", "M", "M", "J", "V", "S"].map((day, index) => (
                                    <div key={index} className={styles.miniDayHeader}>{day}</div>
                                ))}
                                {generateCalendarGrid().map((day, index) => (
                                    <div
                                        key={index}
                                        className={`${styles.miniDayCell} ${day === currentDate.getDate() ? styles.currentDay : ""}`}
                                    >
                                        {day}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === "preparar" && (
                    <div className={styles.tabContent}>
                        <h2>Subir Carta y Propuesta</h2>
                        <div className={styles["file-section"]}>
                            <button
                                className={styles["file-button"]}
                                onClick={() => document.getElementById("file-input").click()}
                            >
                                Elegir Archivos
                            </button>
                            <input
                                id="file-input"
                                type="file"
                                accept=".pdf"
                                multiple
                                onChange={handleFileSelect}
                                style={{ display: "none" }}
                            />
                        </div>
                        <div className={styles["file-preview"]}>
                            {selectedFiles.length > 0 ? (
                                selectedFiles.map((file, index) => (
                                    <div key={index} className={styles["file-item"]}>
                                        <span>{file.name}</span>
                                        <img
                                            src={iconoEliminarBasura}
                                            alt="Eliminar archivo"
                                            className={styles["delete-icon"]}
                                            onClick={() => handleRemoveFile(index)}
                                        />
                                    </div>
                                ))
                            ) : (
                                <p>No se han seleccionado archivos</p>
                            )}
                        </div>
                        <div className={styles["action-buttons"]}>
                            <button className={styles["btn-submit"]} onClick={handleSubmitPropuesta}>
                                Enviar
                            </button>
                            <button className={styles["btn-clear"]} onClick={handleClearFiles}>
                                Limpiar los archivos seleccionados
                            </button>
                        </div>
                            
                        <div className={styles["download-section"]}>
                            <a
                                href={formatoCartaPropuesta}
                                download="Formato_Carta_Propuesta.pdf"
                                className={styles["download-button"]}
                            >
                                Descargar Formato de Carta y Propuesta
                            </a>
                        </div>
                    </div>
                )}

                {activeTab === "estado" && (
                    <div className={styles.tabContent}>
                        <h2>Propuestas Subidas</h2>
                        <div className={styles.propuestasList}>
                            {propuestas.map((propuesta) => (
                                <div key={propuesta.id} className={styles.propuestaCard}>
                                    <h3>{propuesta.title}</h3>
                                    <p><strong>Fecha de Subida:</strong> {propuesta.created_at}</p>
                                    <p><strong>Estado:</strong> {propuesta.state_id}</p>
                                    <p><strong>Observación:</strong> {propuesta.description}</p>
                                    <button onClick={() => handleEditModal(propuesta)} className={styles["edit-button"]}>
                                        Editar Archivo
                                    </button>
                                    <button onClick={() => handleDeletePropuesta(propuesta.id)} className={styles["delete-button"]}>
                                        Eliminar
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
            <Modal
                isOpen={isEditModalOpen}
                onRequestClose={() => setIsEditModalOpen(false)}
                contentLabel="Editar Archivo de Propuesta"
                className={styles.editModal}
                overlayClassName={styles.overlay}
            >
                <h2>Editar Archivo de Propuesta</h2>
                <input type="file" accept=".pdf" />
                <div className={styles["button-group"]}>
                    <button className={styles["save-button"]}>Guardar Cambios</button>
                    <button onClick={() => setIsEditModalOpen(false)} className={styles["cancel-button"]}>
                        Cancelar
                    </button>
                </div>
            </Modal>

            <Modal
                isOpen={isAyudaModalOpen}
                onRequestClose={handleCloseAyuda}
                contentLabel="Ayuda"
                className={styles.ayudaModal}
                overlayClassName={styles.overlay}
            >
                <button className={styles.closeButton} onClick={handleCloseAyuda}>
                    ✖
                </button>
                {renderAyudaContenido()}
            </Modal>
            <footer className={styles.footer}>
                <p>&copy; {new Date().getFullYear()} Universidad de Catolica Boliviana. Todos los derechos reservados.</p>
                <div className={styles.footerLinks}>
                    <button
                        className={styles.footerButton}
                        onClick={() => setFooterContent("Política de Privacidad: Manejaremos tu informacion personal de la siguiente manera...")}
                    >
                        Política de Privacidad
                    </button>
                    <button
                        className={styles.footerButton}
                        onClick={() => setFooterContent("Términos y Condiciones: Este acuerdo regula tu uso de la plataforma...")}
                    >
                        Términos y Condiciones
                    </button>
                    <button
                        className={styles.footerButton}
                        onClick={() => setFooterContent("Contacto: Puedes comunicarte con nosotros a través de universidadCatolica@gmail.com")}
                    >
                        Contacto
                    </button>
                </div>
            </footer>

            {footerContent && (
                <div className={styles.overlay}>
                    <div className={styles.dynamicContent}>
                        <button className={styles.closeButton} onClick={() => setFooterContent("")}>✖</button>
                        <h3>Información</h3>
                        <p>{footerContent}</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Estudiante;
