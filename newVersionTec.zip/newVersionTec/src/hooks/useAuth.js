import jwtDecode from "jwt-decode";

export const useAuth = () => {
  const token = localStorage.getItem("accessToken");
  if (!token) return null;

  try {
    const decoded = jwtDecode(token);
    return decoded; // Retorna los datos decodificados del token
  } catch (error) {
    console.error("Error al decodificar el token:", error);
    return null;
  }
};
